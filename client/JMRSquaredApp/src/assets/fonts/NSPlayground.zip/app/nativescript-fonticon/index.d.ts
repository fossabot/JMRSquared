export declare class TNSFontIcon {
    static css: any;
    static paths: any;
    static debug: boolean;
    static loadCss(): void;
}
export declare function fonticon(value: string): string;
