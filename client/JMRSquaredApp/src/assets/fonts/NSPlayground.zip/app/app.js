const Vue = require("nativescript-vue");
const { TNSFontIcon, fonticon } = require('./nativescript-fonticon');

TNSFontIcon.paths = {
  fa: './FontAwesome.css',
};
TNSFontIcon.loadCss();

Vue.filter('fonticon', fonticon);

new Vue({

  template: `
    <Page class="page">
      <ActionBar title="Home" class="action-bar" />
      <ScrollView>
        <StackLayout class="home-panel">
          <Label class="fa" :text="'fa-user' | fonticon" />
        </StackLayout>
      </ScrollView>
    </Page>
  `,

}).$start();